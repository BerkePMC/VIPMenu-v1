<?php

namespace VipMenu;

use pocketmine\plugin\PluginBase;
use pocketmine\command\{Command, CommandSender, ConsoleCommandSender, CommandExecutor};
use pocketmine\{Player, Server};
use jojoe77777\FormAPI;
use pocketmine\event\Listener;
use pocketmine\entity\Effect;
use pocketmine\item\Item;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("VIPMenu Aktif");
	}
	
	public function onCommand(CommandSender $o, Command $kmt, string $label, array $args): bool{
		switch($kmt->getName()){
			case "vipmenu":
			$this->abForm($o);
		}
		return true;
	}
	
	public function abForm(Player $o){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $o, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			
			switch($re){
				case 0:
				if($o->hasPermission("can.ozel")){
					$o->sendMessage("§a[✓] Canın Başarıyla Doldu!");
					$o->setHealth(20);
				}else{
					$o->sendMessage("§c[×] Üzgünüm bu komutu kullanabilmek için VIP üyelik sahibi olmalısın!");
				}
				break;
			}
			switch($re){
				case 1:
				if($o->hasPermission("yemek.ozel")){
					$o->sendMessage("§c[✓] Açlığın Başarıyla Giderildi!");
					$o->setFood(20);
				}else{
					$o->sendMessage("§c[×] Üzgünüm bu komutu kullanabilmek için VIP üyelik sahibi olmalısın!");
				}
				break;
			}
			switch($re){
				case 2:
				if($o->hasPermission("uc.ozel")){
					$o->sendMessage("§a[✓] Artık Uçabilirsin!");
					$o->setAllowFlight(true);
				}else{
					$o->sendMessage("§c[×] Üzgünüm bu komutu kullanabilmek için VIP üyelik sahibi olmalısın!");
				}
				break;
			}
			switch($re){
				case 3:
				if($o->hasPermission("fly.ozel")){
					$o->sendMessage("§c[✓] Artık Uçamıyorsun!");
					$o->setAllowFlight(false);
				}else{
					$o->sendMessage("§c[×] Üzgünüm bu komutu kullanabilmek için VIP üyelik sahibi olmalısın!");
				}
				break;
			}
			switch($re){
				case 4:
				if($o->hasPermission("tamir.ozel")){
					$o->sendMessage("§a[✓] Elindeki eşya başarıyla onarıldı!");
					$item = $o->getPlayer()->getInventory()->getItemInHand();
          $item->setDamage(0);
          $o->getPlayer()->getInventory()->setItemInHand($item);
				}else{
					$o->sendMessage("§c[×] Üzgünüm bu komutu kullanabilmek için VIP üyelik sahibi olmalısın!");
				}
				break;
			}
			switch($re){
			    case 5:
			        if($o->hasPermission("clear.ozel")){
			            $o->sendMessage("§a[✓] Envanterin Başarıyla Sıfırlandı!");
			            $o->getInventory()->clearAll();
			            $o->getArmorInventory()->clearAll();
			        }else{
			            $o->sendMessage("§c[×] Üzgünüm bu komutu kullanabilmek için VIP üyelik sahibi olmalısın!");
			        }
			}
			switch($re){
				case 6:
				$o->sendMessage("§a[✓] Başarıyla Menüden Ayrıldın!");
				break;
			}
		});
		
		$ad = $o->getPlayer()->getName();
		$f->setTitle("§aVIP Menü");
		$f->setContent("§aHoşgeldin $ad Buradan sana verilen yetkiler ile komutları kullanabilirsin!");
		$f->addButton("§aCan - Heal \n §7Tıkla Yenile", 0, "textures/items/bread");
		$f->addButton("§aAçlık - Feed \n §7Tıkla Doldur", 0, "textures/items/beef");
		$f->addButton("§aUçma - Fly \n §7Tıkla Aç", 0, "textures/items/elytra");
		$f->addButton("§aUçma Modunu Kapat \n §7Tıkla ve Kapat", 0, "textures/blocks/diamond_block");
		$f->addButton("§aTamir - Repair \n §7Tıkla Tamir", 0, "textures/items/iron_sword");
		$f->addButton("§aEnvanter - İnventory \n §7Tıkla Temizle", 0, "textures/items/paper");
		$f->addButton("§cÇıkış - Exit \n §7Tıkla Çık", 0, "textures/blocks/obsidian");
		$f->sendToPlayer($o);
	}
}
?>